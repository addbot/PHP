<?php
/************************************************************
 * Filename  : otb.php
 * Purpose   : This is a constant file which will house all the
 * constants that can be used globally.
 * This code is part of the request from otb company. c/0 Abi Hart
 * Author(s) : marvin
 * Date      : Date(July 1, 2019)
 */
define("ERROR_SELF_DEPENDENT","Jobs can't depend on themselves");
define("ERROR_CYCLIC_DEPENDENT","Jobs can't have circular dependencies");


?>